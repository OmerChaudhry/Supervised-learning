from knn import KNNClassifier as knnClass
from perceptron import Perceptron as perClass
